Numerical Analysis
==================
The programs in the folder "pascal"
is from the book

    Numerical Analysis, 9th ed.
    Burden & Faires 

See    
http://www.math.ysu.edu/~faires/Numerical-Analysis/Programs/
